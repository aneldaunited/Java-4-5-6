public interface Player {

    public boolean checkForNumber(int checkNumbers);
    public void chooseNumbers();
    public String printRemaining();
    public boolean checkIfWon();
}
